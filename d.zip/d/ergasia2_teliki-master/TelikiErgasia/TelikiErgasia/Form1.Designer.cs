﻿namespace TelikiErgasia
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.x1 = new System.Windows.Forms.Label();
            this.x2 = new System.Windows.Forms.Label();
            this.x3 = new System.Windows.Forms.Label();
            this.x4 = new System.Windows.Forms.Label();
            this.x5 = new System.Windows.Forms.Label();
            this.x6 = new System.Windows.Forms.Label();
            this.x7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.y9 = new System.Windows.Forms.Label();
            this.y8 = new System.Windows.Forms.Label();
            this.y7 = new System.Windows.Forms.Label();
            this.y6 = new System.Windows.Forms.Label();
            this.y5 = new System.Windows.Forms.Label();
            this.y4 = new System.Windows.Forms.Label();
            this.y3 = new System.Windows.Forms.Label();
            this.y2 = new System.Windows.Forms.Label();
            this.y1 = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Label();
            this.x8 = new System.Windows.Forms.Label();
            this.x9 = new System.Windows.Forms.Label();
            this.p1 = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Label();
            this.p4 = new System.Windows.Forms.Label();
            this.p5 = new System.Windows.Forms.Label();
            this.p6 = new System.Windows.Forms.Label();
            this.p7 = new System.Windows.Forms.Label();
            this.p8 = new System.Windows.Forms.Label();
            this.p9 = new System.Windows.Forms.Label();
            this.x10 = new System.Windows.Forms.Label();
            this.p10 = new System.Windows.Forms.Label();
            this.y10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.Label();
            this.play = new System.Windows.Forms.Button();
            this.sec = new System.Windows.Forms.Timer(this.components);
            this.ap1 = new System.Windows.Forms.NumericUpDown();
            this.ap2 = new System.Windows.Forms.NumericUpDown();
            this.ap3 = new System.Windows.Forms.NumericUpDown();
            this.ap4 = new System.Windows.Forms.NumericUpDown();
            this.ap5 = new System.Windows.Forms.NumericUpDown();
            this.ap7 = new System.Windows.Forms.NumericUpDown();
            this.ap6 = new System.Windows.Forms.NumericUpDown();
            this.ap9 = new System.Windows.Forms.NumericUpDown();
            this.ap8 = new System.Windows.Forms.NumericUpDown();
            this.ap10 = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ap1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap10)).BeginInit();
            this.SuspendLayout();
            // 
            // x1
            // 
            this.x1.AutoSize = true;
            this.x1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x1.Location = new System.Drawing.Point(3, 0);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(27, 21);
            this.x1.TabIndex = 0;
            this.x1.Text = "X";
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x2.Location = new System.Drawing.Point(3, 21);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(27, 23);
            this.x2.TabIndex = 1;
            this.x2.Text = "X";
            // 
            // x3
            // 
            this.x3.AutoSize = true;
            this.x3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x3.Location = new System.Drawing.Point(3, 44);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(27, 24);
            this.x3.TabIndex = 2;
            this.x3.Text = "X";
            this.x3.Click += new System.EventHandler(this.label3_Click);
            // 
            // x4
            // 
            this.x4.AutoSize = true;
            this.x4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x4.Location = new System.Drawing.Point(3, 68);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(27, 25);
            this.x4.TabIndex = 3;
            this.x4.Text = "X";
            this.x4.Click += new System.EventHandler(this.label4_Click);
            // 
            // x5
            // 
            this.x5.AutoSize = true;
            this.x5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x5.Location = new System.Drawing.Point(3, 95);
            this.x5.Name = "x5";
            this.x5.Size = new System.Drawing.Size(27, 25);
            this.x5.TabIndex = 4;
            this.x5.Text = "X";
            this.x5.Click += new System.EventHandler(this.label5_Click);
            // 
            // x6
            // 
            this.x6.AutoSize = true;
            this.x6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x6.Location = new System.Drawing.Point(3, 121);
            this.x6.Name = "x6";
            this.x6.Size = new System.Drawing.Size(27, 25);
            this.x6.TabIndex = 5;
            this.x6.Text = "X";
            // 
            // x7
            // 
            this.x7.AutoSize = true;
            this.x7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x7.Location = new System.Drawing.Point(3, 147);
            this.x7.Name = "x7";
            this.x7.Size = new System.Drawing.Size(27, 25);
            this.x7.TabIndex = 6;
            this.x7.Text = "X";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.40541F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.59459F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanel1.Controls.Add(this.y9, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.y8, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.y7, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.y6, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.y5, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.y4, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.y3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.y2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.y1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.p3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.x2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.x3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.x5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.x4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.x1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.x8, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.x9, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.p1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.p2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.p4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.p5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.p6, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.p7, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.p8, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.p9, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.x10, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.p10, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.x6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.x7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.y10, 2, 9);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(161, 88);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.93877F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.06123F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(260, 314);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // y9
            // 
            this.y9.AutoSize = true;
            this.y9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y9.Location = new System.Drawing.Point(189, 200);
            this.y9.Name = "y9";
            this.y9.Size = new System.Drawing.Size(28, 25);
            this.y9.TabIndex = 27;
            this.y9.Text = "Y";
            // 
            // y8
            // 
            this.y8.AutoSize = true;
            this.y8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y8.Location = new System.Drawing.Point(189, 172);
            this.y8.Name = "y8";
            this.y8.Size = new System.Drawing.Size(28, 25);
            this.y8.TabIndex = 27;
            this.y8.Text = "Y";
            // 
            // y7
            // 
            this.y7.AutoSize = true;
            this.y7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y7.Location = new System.Drawing.Point(189, 147);
            this.y7.Name = "y7";
            this.y7.Size = new System.Drawing.Size(28, 25);
            this.y7.TabIndex = 26;
            this.y7.Text = "Y";
            // 
            // y6
            // 
            this.y6.AutoSize = true;
            this.y6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y6.Location = new System.Drawing.Point(189, 121);
            this.y6.Name = "y6";
            this.y6.Size = new System.Drawing.Size(28, 25);
            this.y6.TabIndex = 25;
            this.y6.Text = "Y";
            // 
            // y5
            // 
            this.y5.AutoSize = true;
            this.y5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y5.Location = new System.Drawing.Point(189, 95);
            this.y5.Name = "y5";
            this.y5.Size = new System.Drawing.Size(28, 25);
            this.y5.TabIndex = 24;
            this.y5.Text = "Y";
            // 
            // y4
            // 
            this.y4.AutoSize = true;
            this.y4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y4.Location = new System.Drawing.Point(189, 68);
            this.y4.Name = "y4";
            this.y4.Size = new System.Drawing.Size(28, 25);
            this.y4.TabIndex = 23;
            this.y4.Text = "Y";
            // 
            // y3
            // 
            this.y3.AutoSize = true;
            this.y3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y3.Location = new System.Drawing.Point(189, 44);
            this.y3.Name = "y3";
            this.y3.Size = new System.Drawing.Size(28, 24);
            this.y3.TabIndex = 22;
            this.y3.Text = "Y";
            // 
            // y2
            // 
            this.y2.AutoSize = true;
            this.y2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y2.Location = new System.Drawing.Point(189, 21);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(28, 23);
            this.y2.TabIndex = 21;
            this.y2.Text = "Y";
            // 
            // y1
            // 
            this.y1.AutoSize = true;
            this.y1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y1.Location = new System.Drawing.Point(189, 0);
            this.y1.Name = "y1";
            this.y1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.y1.Size = new System.Drawing.Size(28, 21);
            this.y1.TabIndex = 20;
            this.y1.Text = "Y";
            // 
            // p3
            // 
            this.p3.AutoSize = true;
            this.p3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p3.Location = new System.Drawing.Point(87, 44);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(65, 24);
            this.p3.TabIndex = 13;
            this.p3.Text = "pra3i";
            // 
            // x8
            // 
            this.x8.AutoSize = true;
            this.x8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x8.Location = new System.Drawing.Point(3, 172);
            this.x8.Name = "x8";
            this.x8.Size = new System.Drawing.Size(27, 25);
            this.x8.TabIndex = 7;
            this.x8.Text = "X";
            // 
            // x9
            // 
            this.x9.AutoSize = true;
            this.x9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x9.Location = new System.Drawing.Point(3, 200);
            this.x9.Name = "x9";
            this.x9.Size = new System.Drawing.Size(27, 25);
            this.x9.TabIndex = 8;
            this.x9.Text = "X";
            // 
            // p1
            // 
            this.p1.AutoSize = true;
            this.p1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p1.Location = new System.Drawing.Point(87, 0);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(65, 21);
            this.p1.TabIndex = 9;
            this.p1.Text = "pra3i";
            // 
            // p2
            // 
            this.p2.AutoSize = true;
            this.p2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p2.Location = new System.Drawing.Point(87, 21);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(65, 23);
            this.p2.TabIndex = 10;
            this.p2.Text = "pra3i";
            // 
            // p4
            // 
            this.p4.AutoSize = true;
            this.p4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p4.Location = new System.Drawing.Point(87, 68);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(65, 25);
            this.p4.TabIndex = 11;
            this.p4.Text = "pra3i";
            // 
            // p5
            // 
            this.p5.AutoSize = true;
            this.p5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p5.Location = new System.Drawing.Point(87, 95);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(65, 25);
            this.p5.TabIndex = 12;
            this.p5.Text = "pra3i";
            // 
            // p6
            // 
            this.p6.AutoSize = true;
            this.p6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p6.Location = new System.Drawing.Point(87, 121);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(65, 25);
            this.p6.TabIndex = 14;
            this.p6.Text = "pra3i";
            // 
            // p7
            // 
            this.p7.AutoSize = true;
            this.p7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p7.Location = new System.Drawing.Point(87, 147);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(65, 25);
            this.p7.TabIndex = 15;
            this.p7.Text = "pra3i";
            // 
            // p8
            // 
            this.p8.AutoSize = true;
            this.p8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p8.Location = new System.Drawing.Point(87, 172);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(65, 25);
            this.p8.TabIndex = 16;
            this.p8.Text = "pra3i";
            // 
            // p9
            // 
            this.p9.AutoSize = true;
            this.p9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p9.Location = new System.Drawing.Point(87, 200);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(65, 25);
            this.p9.TabIndex = 17;
            this.p9.Text = "pra3i";
            // 
            // x10
            // 
            this.x10.AutoSize = true;
            this.x10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x10.Location = new System.Drawing.Point(3, 230);
            this.x10.Name = "x10";
            this.x10.Size = new System.Drawing.Size(27, 25);
            this.x10.TabIndex = 18;
            this.x10.Text = "X";
            // 
            // p10
            // 
            this.p10.AutoSize = true;
            this.p10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p10.Location = new System.Drawing.Point(87, 230);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(65, 25);
            this.p10.TabIndex = 19;
            this.p10.Text = "pra3i";
            // 
            // y10
            // 
            this.y10.AutoSize = true;
            this.y10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y10.Location = new System.Drawing.Point(189, 230);
            this.y10.Name = "y10";
            this.y10.Size = new System.Drawing.Size(28, 25);
            this.y10.TabIndex = 28;
            this.y10.Text = "Y";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(673, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 33);
            this.label1.TabIndex = 7;
            this.label1.Text = "Χρόνος:";
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.time.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.Location = new System.Drawing.Point(790, 7);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(77, 35);
            this.time.TabIndex = 8;
            this.time.Text = "2:00";
            this.time.Click += new System.EventHandler(this.time_Click);
            // 
            // play
            // 
            this.play.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.play.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.play.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.play.Location = new System.Drawing.Point(358, 435);
            this.play.Name = "play";
            this.play.Size = new System.Drawing.Size(366, 45);
            this.play.TabIndex = 9;
            this.play.Text = "Ξεκινήστε το Quiz";
            this.play.UseVisualStyleBackColor = false;
            this.play.Click += new System.EventHandler(this.play_Click);
            // 
            // sec
            // 
            this.sec.Interval = 1000;
            this.sec.Tick += new System.EventHandler(this.sec_Tick);
            // 
            // ap1
            // 
            this.ap1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap1.Enabled = false;
            this.ap1.Location = new System.Drawing.Point(427, 89);
            this.ap1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap1.Name = "ap1";
            this.ap1.Size = new System.Drawing.Size(120, 20);
            this.ap1.TabIndex = 20;
            // 
            // ap2
            // 
            this.ap2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap2.Enabled = false;
            this.ap2.Location = new System.Drawing.Point(427, 112);
            this.ap2.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap2.Name = "ap2";
            this.ap2.Size = new System.Drawing.Size(120, 20);
            this.ap2.TabIndex = 21;
            // 
            // ap3
            // 
            this.ap3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap3.Enabled = false;
            this.ap3.Location = new System.Drawing.Point(427, 136);
            this.ap3.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap3.Name = "ap3";
            this.ap3.Size = new System.Drawing.Size(120, 20);
            this.ap3.TabIndex = 22;
            // 
            // ap4
            // 
            this.ap4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap4.Enabled = false;
            this.ap4.Location = new System.Drawing.Point(427, 160);
            this.ap4.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap4.Name = "ap4";
            this.ap4.Size = new System.Drawing.Size(120, 20);
            this.ap4.TabIndex = 23;
            // 
            // ap5
            // 
            this.ap5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap5.Enabled = false;
            this.ap5.Location = new System.Drawing.Point(427, 187);
            this.ap5.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap5.Name = "ap5";
            this.ap5.Size = new System.Drawing.Size(120, 20);
            this.ap5.TabIndex = 24;
            // 
            // ap7
            // 
            this.ap7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap7.Enabled = false;
            this.ap7.Location = new System.Drawing.Point(427, 239);
            this.ap7.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap7.Name = "ap7";
            this.ap7.Size = new System.Drawing.Size(120, 20);
            this.ap7.TabIndex = 25;
            // 
            // ap6
            // 
            this.ap6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap6.Enabled = false;
            this.ap6.Location = new System.Drawing.Point(427, 213);
            this.ap6.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap6.Name = "ap6";
            this.ap6.Size = new System.Drawing.Size(120, 20);
            this.ap6.TabIndex = 26;
            // 
            // ap9
            // 
            this.ap9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap9.Enabled = false;
            this.ap9.Location = new System.Drawing.Point(427, 292);
            this.ap9.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap9.Name = "ap9";
            this.ap9.Size = new System.Drawing.Size(120, 20);
            this.ap9.TabIndex = 27;
            // 
            // ap8
            // 
            this.ap8.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap8.Enabled = false;
            this.ap8.Location = new System.Drawing.Point(427, 264);
            this.ap8.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap8.Name = "ap8";
            this.ap8.Size = new System.Drawing.Size(120, 20);
            this.ap8.TabIndex = 28;
            // 
            // ap10
            // 
            this.ap10.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ap10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ap10.Enabled = false;
            this.ap10.Location = new System.Drawing.Point(427, 322);
            this.ap10.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ap10.Name = "ap10";
            this.ap10.Size = new System.Drawing.Size(120, 20);
            this.ap10.TabIndex = 29;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(679, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "ΤΕΛΟΣ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(679, 318);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 31;
            this.button2.Text = "Calculator";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1264, 749);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ap10);
            this.Controls.Add(this.ap8);
            this.Controls.Add(this.ap9);
            this.Controls.Add(this.ap6);
            this.Controls.Add(this.ap7);
            this.Controls.Add(this.ap5);
            this.Controls.Add(this.ap4);
            this.Controls.Add(this.ap3);
            this.Controls.Add(this.ap2);
            this.Controls.Add(this.ap1);
            this.Controls.Add(this.play);
            this.Controls.Add(this.time);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Math Quiz";
            this.TransparencyKey = System.Drawing.Color.White;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ap1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ap10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label x1;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label x3;
        private System.Windows.Forms.Label x4;
        private System.Windows.Forms.Label x5;
        private System.Windows.Forms.Label x7;
        private System.Windows.Forms.Label x6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label y9;
        private System.Windows.Forms.Label y8;
        private System.Windows.Forms.Label y7;
        private System.Windows.Forms.Label y6;
        private System.Windows.Forms.Label y5;
        private System.Windows.Forms.Label y4;
        private System.Windows.Forms.Label y3;
        private System.Windows.Forms.Label y2;
        private System.Windows.Forms.Label y1;
        private System.Windows.Forms.Label p3;
        private System.Windows.Forms.Label x8;
        private System.Windows.Forms.Label x9;
        private System.Windows.Forms.Label p1;
        private System.Windows.Forms.Label p2;
        private System.Windows.Forms.Label p4;
        private System.Windows.Forms.Label p5;
        private System.Windows.Forms.Label p6;
        private System.Windows.Forms.Label p7;
        private System.Windows.Forms.Label p8;
        private System.Windows.Forms.Label p9;
        private System.Windows.Forms.Label x10;
        private System.Windows.Forms.Label p10;
        private System.Windows.Forms.Label y10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Button play;
        private System.Windows.Forms.Timer sec;
        public System.Windows.Forms.NumericUpDown ap1;
        public System.Windows.Forms.NumericUpDown ap2;
        public System.Windows.Forms.NumericUpDown ap3;
        public System.Windows.Forms.NumericUpDown ap4;
        public System.Windows.Forms.NumericUpDown ap5;
        public System.Windows.Forms.NumericUpDown ap7;
        public System.Windows.Forms.NumericUpDown ap6;
        public System.Windows.Forms.NumericUpDown ap9;
        public System.Windows.Forms.NumericUpDown ap8;
        public System.Windows.Forms.NumericUpDown ap10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

