﻿namespace MemoryGame
{
    partial class TopScores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.x1 = new System.Windows.Forms.Label();
            this.y1 = new System.Windows.Forms.Label();
            this.p1 = new System.Windows.Forms.Label();
            this.x2 = new System.Windows.Forms.Label();
            this.y2 = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Label();
            this.x3 = new System.Windows.Forms.Label();
            this.y3 = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Label();
            this.x4 = new System.Windows.Forms.Label();
            this.y4 = new System.Windows.Forms.Label();
            this.p4 = new System.Windows.Forms.Label();
            this.x5 = new System.Windows.Forms.Label();
            this.y5 = new System.Windows.Forms.Label();
            this.p5 = new System.Windows.Forms.Label();
            this.x6 = new System.Windows.Forms.Label();
            this.y6 = new System.Windows.Forms.Label();
            this.p6 = new System.Windows.Forms.Label();
            this.x7 = new System.Windows.Forms.Label();
            this.y7 = new System.Windows.Forms.Label();
            this.p7 = new System.Windows.Forms.Label();
            this.x8 = new System.Windows.Forms.Label();
            this.y8 = new System.Windows.Forms.Label();
            this.p8 = new System.Windows.Forms.Label();
            this.x9 = new System.Windows.Forms.Label();
            this.y9 = new System.Windows.Forms.Label();
            this.p9 = new System.Windows.Forms.Label();
            this.x10 = new System.Windows.Forms.Label();
            this.y10 = new System.Windows.Forms.Label();
            this.p10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 214F));
            this.tableLayoutPanel1.Controls.Add(this.p10, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.x10, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.y10, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.p9, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.y9, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.x9, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.p8, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.y8, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.x8, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.p7, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.y7, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.x7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.p6, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.y6, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.x6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.p5, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.y5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.x5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.p4, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.y4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.x4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.p3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.y3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.x3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.p2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.y2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.x2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.p1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.y1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.x1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(102, 56);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.61111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.38889F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(618, 358);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // x1
            // 
            this.x1.AutoSize = true;
            this.x1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x1.Location = new System.Drawing.Point(3, 0);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(24, 33);
            this.x1.TabIndex = 0;
            this.x1.Text = " ";
            this.x1.Click += new System.EventHandler(this.label1_Click);
            // 
            // y1
            // 
            this.y1.AutoSize = true;
            this.y1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y1.Location = new System.Drawing.Point(205, 0);
            this.y1.Name = "y1";
            this.y1.Size = new System.Drawing.Size(24, 33);
            this.y1.TabIndex = 1;
            this.y1.Text = " ";
            // 
            // p1
            // 
            this.p1.AutoSize = true;
            this.p1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p1.Location = new System.Drawing.Point(407, 0);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(24, 33);
            this.p1.TabIndex = 2;
            this.p1.Text = " ";
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x2.Location = new System.Drawing.Point(3, 35);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(24, 33);
            this.x2.TabIndex = 3;
            this.x2.Text = " ";
            // 
            // y2
            // 
            this.y2.AutoSize = true;
            this.y2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y2.Location = new System.Drawing.Point(205, 35);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(24, 33);
            this.y2.TabIndex = 4;
            this.y2.Text = " ";
            // 
            // p2
            // 
            this.p2.AutoSize = true;
            this.p2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p2.Location = new System.Drawing.Point(407, 35);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(24, 33);
            this.p2.TabIndex = 5;
            this.p2.Text = " ";
            // 
            // x3
            // 
            this.x3.AutoSize = true;
            this.x3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x3.Location = new System.Drawing.Point(3, 72);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(24, 33);
            this.x3.TabIndex = 6;
            this.x3.Text = " ";
            this.x3.Click += new System.EventHandler(this.label7_Click);
            // 
            // y3
            // 
            this.y3.AutoSize = true;
            this.y3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y3.Location = new System.Drawing.Point(205, 72);
            this.y3.Name = "y3";
            this.y3.Size = new System.Drawing.Size(24, 33);
            this.y3.TabIndex = 7;
            this.y3.Text = " ";
            // 
            // p3
            // 
            this.p3.AutoSize = true;
            this.p3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p3.Location = new System.Drawing.Point(407, 72);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(24, 33);
            this.p3.TabIndex = 8;
            this.p3.Text = " ";
            // 
            // x4
            // 
            this.x4.AutoSize = true;
            this.x4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x4.Location = new System.Drawing.Point(3, 113);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(24, 33);
            this.x4.TabIndex = 9;
            this.x4.Text = " ";
            // 
            // y4
            // 
            this.y4.AutoSize = true;
            this.y4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y4.Location = new System.Drawing.Point(205, 113);
            this.y4.Name = "y4";
            this.y4.Size = new System.Drawing.Size(24, 33);
            this.y4.TabIndex = 10;
            this.y4.Text = " ";
            // 
            // p4
            // 
            this.p4.AutoSize = true;
            this.p4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p4.Location = new System.Drawing.Point(407, 113);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(24, 33);
            this.p4.TabIndex = 11;
            this.p4.Text = " ";
            // 
            // x5
            // 
            this.x5.AutoSize = true;
            this.x5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x5.Location = new System.Drawing.Point(3, 147);
            this.x5.Name = "x5";
            this.x5.Size = new System.Drawing.Size(24, 33);
            this.x5.TabIndex = 12;
            this.x5.Text = " ";
            // 
            // y5
            // 
            this.y5.AutoSize = true;
            this.y5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y5.Location = new System.Drawing.Point(205, 147);
            this.y5.Name = "y5";
            this.y5.Size = new System.Drawing.Size(24, 33);
            this.y5.TabIndex = 13;
            this.y5.Text = " ";
            // 
            // p5
            // 
            this.p5.AutoSize = true;
            this.p5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p5.Location = new System.Drawing.Point(407, 147);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(24, 33);
            this.p5.TabIndex = 14;
            this.p5.Text = " ";
            // 
            // x6
            // 
            this.x6.AutoSize = true;
            this.x6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x6.Location = new System.Drawing.Point(3, 188);
            this.x6.Name = "x6";
            this.x6.Size = new System.Drawing.Size(24, 33);
            this.x6.TabIndex = 15;
            this.x6.Text = " ";
            // 
            // y6
            // 
            this.y6.AutoSize = true;
            this.y6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y6.Location = new System.Drawing.Point(205, 188);
            this.y6.Name = "y6";
            this.y6.Size = new System.Drawing.Size(24, 33);
            this.y6.TabIndex = 16;
            this.y6.Text = " ";
            // 
            // p6
            // 
            this.p6.AutoSize = true;
            this.p6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p6.Location = new System.Drawing.Point(407, 188);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(24, 33);
            this.p6.TabIndex = 17;
            this.p6.Text = " ";
            // 
            // x7
            // 
            this.x7.AutoSize = true;
            this.x7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x7.Location = new System.Drawing.Point(3, 223);
            this.x7.Name = "x7";
            this.x7.Size = new System.Drawing.Size(24, 33);
            this.x7.TabIndex = 18;
            this.x7.Text = " ";
            // 
            // y7
            // 
            this.y7.AutoSize = true;
            this.y7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y7.Location = new System.Drawing.Point(205, 223);
            this.y7.Name = "y7";
            this.y7.Size = new System.Drawing.Size(24, 33);
            this.y7.TabIndex = 19;
            this.y7.Text = " ";
            // 
            // p7
            // 
            this.p7.AutoSize = true;
            this.p7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p7.Location = new System.Drawing.Point(407, 223);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(24, 33);
            this.p7.TabIndex = 20;
            this.p7.Text = " ";
            // 
            // x8
            // 
            this.x8.AutoSize = true;
            this.x8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x8.Location = new System.Drawing.Point(3, 256);
            this.x8.Name = "x8";
            this.x8.Size = new System.Drawing.Size(24, 33);
            this.x8.TabIndex = 21;
            this.x8.Text = " ";
            // 
            // y8
            // 
            this.y8.AutoSize = true;
            this.y8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y8.Location = new System.Drawing.Point(205, 256);
            this.y8.Name = "y8";
            this.y8.Size = new System.Drawing.Size(24, 33);
            this.y8.TabIndex = 22;
            this.y8.Text = " ";
            // 
            // p8
            // 
            this.p8.AutoSize = true;
            this.p8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p8.Location = new System.Drawing.Point(407, 256);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(24, 33);
            this.p8.TabIndex = 23;
            this.p8.Text = " ";
            // 
            // x9
            // 
            this.x9.AutoSize = true;
            this.x9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x9.Location = new System.Drawing.Point(3, 291);
            this.x9.Name = "x9";
            this.x9.Size = new System.Drawing.Size(24, 33);
            this.x9.TabIndex = 24;
            this.x9.Text = " ";
            // 
            // y9
            // 
            this.y9.AutoSize = true;
            this.y9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y9.Location = new System.Drawing.Point(205, 291);
            this.y9.Name = "y9";
            this.y9.Size = new System.Drawing.Size(24, 33);
            this.y9.TabIndex = 25;
            this.y9.Text = " ";
            // 
            // p9
            // 
            this.p9.AutoSize = true;
            this.p9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p9.Location = new System.Drawing.Point(407, 291);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(24, 33);
            this.p9.TabIndex = 26;
            this.p9.Text = " ";
            // 
            // x10
            // 
            this.x10.AutoSize = true;
            this.x10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x10.Location = new System.Drawing.Point(3, 327);
            this.x10.Name = "x10";
            this.x10.Size = new System.Drawing.Size(24, 31);
            this.x10.TabIndex = 27;
            this.x10.Text = " ";
            // 
            // y10
            // 
            this.y10.AutoSize = true;
            this.y10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.y10.Location = new System.Drawing.Point(205, 327);
            this.y10.Name = "y10";
            this.y10.Size = new System.Drawing.Size(24, 31);
            this.y10.TabIndex = 28;
            this.y10.Text = " ";
            // 
            // p10
            // 
            this.p10.AutoSize = true;
            this.p10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p10.Location = new System.Drawing.Point(407, 327);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(24, 31);
            this.p10.TabIndex = 29;
            this.p10.Text = " ";
            // 
            // TopScores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "TopScores";
            this.Text = "TopScores";
            this.Load += new System.EventHandler(this.TopScores_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label x1;
        private System.Windows.Forms.Label p9;
        private System.Windows.Forms.Label y9;
        private System.Windows.Forms.Label x9;
        private System.Windows.Forms.Label p8;
        private System.Windows.Forms.Label y8;
        private System.Windows.Forms.Label x8;
        private System.Windows.Forms.Label p7;
        private System.Windows.Forms.Label y7;
        private System.Windows.Forms.Label x7;
        private System.Windows.Forms.Label p6;
        private System.Windows.Forms.Label y6;
        private System.Windows.Forms.Label x6;
        private System.Windows.Forms.Label p5;
        private System.Windows.Forms.Label y5;
        private System.Windows.Forms.Label x5;
        private System.Windows.Forms.Label p4;
        private System.Windows.Forms.Label y4;
        private System.Windows.Forms.Label x4;
        private System.Windows.Forms.Label p3;
        private System.Windows.Forms.Label y3;
        private System.Windows.Forms.Label x3;
        private System.Windows.Forms.Label p2;
        private System.Windows.Forms.Label y2;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label p1;
        private System.Windows.Forms.Label y1;
        private System.Windows.Forms.Label x10;
        private System.Windows.Forms.Label p10;
        private System.Windows.Forms.Label y10;
    }
}